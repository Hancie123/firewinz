<!DOCTYPE HTML>
<html>

<head>
    <title>Tech Revo Nepal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <h2 class="text-center">Tech Revo Nepal</h2>

    <p>Tech Revo Nepal have new announcement for you.</p>

    <p>Subject: {{$title}} </p>
    <p>Announcement: {{$announcement}} </p>

    <br>
    <p> Contact us at 9825915122 or techrevonepal@gmail.com if you need any additional support.</p>
    <p>Sincerely,<br>
        Tech Revo Nepal</p>
</body>

</html>