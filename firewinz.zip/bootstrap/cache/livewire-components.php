<?php return array (
  'firewinz-transaction' => 'App\\Http\\Livewire\\FirewinzTransaction',
);