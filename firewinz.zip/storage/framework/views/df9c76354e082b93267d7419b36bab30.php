<?php echo $__env->make('layouts.workernav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startPush('title'); ?>
<title>Firewinz Dashboard</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" />
<link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" />

<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.7.1/css/buttons.dataTables.min.css">
<script src="https://cdn.datatables.net/buttons/1.7.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.print.min.js"></script>


<div class="main-panel">
    <div class="content-wrapper">

        <!-- Check Room Exit Before Clock In -->
        <?php $__errorArgs = ['room_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <script>
        toastr.error("<?php echo e($message); ?>")
        </script>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <!--------------------- The Announcement Modal -------------------->
        <?php if($countannouncement >=1): ?>
        <div class="modal fade" id="announcementmodel">
            <div class="modal-dialog">
                <div class="modal-content">

                    <!-- Modal Header -->
                    <div class="modal-header">
                        <?php $__currentLoopData = $announceall; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h4 class="modal-title"><?php echo e($data->title); ?></h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>

                    <!-- Modal body -->
                    <div class="modal-body">

                        <p style="font-size: 20px"><?php echo $data->announcement; ?></p><br>

                    </div>

                    <!-- Modal footer -->
                    <div class="modal-footer">
                        <p class="text-start">Posted: <?php echo e($data['created_at']->todatestring()); ?></p>
                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>

                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
        <?php else: ?>
        <?php endif; ?>

        <script type="text/javascript">
        window.onload = function() {
            OpenBootstrapPopup();
        };

        function OpenBootstrapPopup() {
            $("#announcementmodel").modal('show');
        }
        </script>
        <!--------------------- The End Announcement Modal -------------------->





        <!-------------------- The Welcome Message Card ------------------------->
        <div class=" card-deck">
            <div class="card shadow">
                <div class="card-body">

                    <div class="container">
                        <div class="row">
                            <div class="col-md-2">
                                <label alt="Profile" class="w3-circle bg-dark p-3 text-white h3">
                                    <b> <?php $name=Session('name'); echo substr("$name",0,1);?></b>
                                </label>
                            </div>

                            <div class="col-md-10">
                                <h3 style="font-weight: bold;">Welcome, <?php echo e(Session('name')); ?></h3>
                                <a class="text-dark" href="<?php echo e(url('/admin/dashboard/logout')); ?>">Sign Out</a>
                            </div>
                        </div>
                    </div>

                </div>
            </div>


            <!---------------------------- Clock in and Clock Out Section Card -------------------------->
            <div class="card shadow">
                <div class="card-body">


                    <?php if($countclockinstatus>=1): ?>
                    <form method='post' action="<?php echo e(url('/admin/clockout')); ?>">
                        <?php if(Session::has('success')): ?>
                        <script>
                        toastr.success("<?php echo e(Session::get('success')); ?>")
                        </script>
                        <?php endif; ?>
                        <?php if(Session::has('fail')): ?>
                        <script>
                        toastr.warning("<?php echo e(Session::get('fail')); ?>")
                        </script>
                        <?php endif; ?>
                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="checkout" value="<?php $timestamp = time();
            echo date('Y-m-d H:i:s', $timestamp); ?>">

                        <input type="hidden" value="<?php echo e(Session::get('User_ID')); ?>" name="User_ID" type="text">

                        <input type="hidden" value="<?php echo date('Y-m-d'); ?>" name="date" type="text">

                        <?php $__currentLoopData = $access_controls2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <input type="hidden" value="<?php echo e($data->room_id); ?>" name="room_id" type="text">
                        <?php break; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <button type="submit" class="btn btn-primary btn-block text-danger"
                            style="height: 2.5em; font-size: 1.7rem;">Clock
                            Out <span><i class=' bx bx-right-arrow-alt bx bx-sm bx-fade-right'></i></span></button>



                    </form>
                    <?php elseif($countclockoutstatus>=1): ?>

                    <form method='post' action="<?php echo e(url('/admin/clockin')); ?>">
                        <?php if(Session::has('success')): ?>
                        <script>
                        toastr.success("<?php echo e(Session::get('success')); ?>")
                        </script>
                        <?php endif; ?>
                        <?php if(Session::has('fail')): ?>
                        <script>
                        toastr.warning("<?php echo e(Session::get('fail')); ?>")
                        </script>
                        <?php endif; ?>
                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="checkin" value="<?php $timestamp = time();
            echo date('Y-m-d H:i:s', $timestamp); ?>">

                        <input type="hidden" value="<?php echo e(Session::get('User_ID')); ?>" name="User_ID" type="text">

                        <input type="hidden" value="<?php echo date('Y-m-d'); ?>" name="date" type="text">

                        <?php $__currentLoopData = $access_controls2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <input type="hidden" value="<?php echo e($data->room_id); ?>" name="room_id" type="text">
                        <?php break; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <button type="submit" class="btn btn-primary btn-block"
                            style="height: 2.5em; font-size: 1.7rem;">Clock
                            In <span><i class=' bx bx-right-arrow-alt bx bx-sm bx-fade-right'></i></span></button>



                    </form>
                    <?php else: ?>

                    <form method='post' action="<?php echo e(url('/admin/newclockin')); ?>">
                        <?php if(Session::has('success')): ?>
                        <script>
                        toastr.success("<?php echo e(Session::get('success')); ?>")
                        </script>
                        <?php endif; ?>
                        <?php if(Session::has('fail')): ?>
                        <script>
                        toastr.warning("<?php echo e(Session::get('fail')); ?>")
                        </script>
                        <?php endif; ?>
                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="checkin" value="<?php $timestamp = time();
            echo date('Y-m-d H:i:s', $timestamp); ?>">

                        <input type="hidden" value="<?php echo e(Session::get('User_ID')); ?>" name="User_ID" type="text">

                        <input type="hidden" value="<?php echo date('Y-m-d'); ?>" name="date" type="text">

                        <?php $__currentLoopData = $access_controls2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <input type="hidden" value="<?php echo e($data->room_id); ?>" name="room_id" type="text">
                        <?php break; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <button type="submit" class="btn btn-primary btn-block"
                            style="height: 2.5em; font-size: 1.7rem;">Clock
                            In <span><i class=' bx bx-right-arrow-alt bx bx-sm bx-fade-right'></i></span></button>



                    </form>
                    <?php endif; ?>



                </div>
            </div>
        </div>



        <br>





        <!-------------------- The Cash Inlow and Outflow Card ------------------------->
        <div class="card-deck">
            <div class="card">
                <div class="card-body">
                    <div class="card-body">
                        <h5 class="card-title"><b>Cash In Amount</b></h5>
                        <div class="d-flex align-items-center">
                            <div class="card-icon bg-primary p-1 rounded-circle d-flex align-items-center">
                                <i class='bx bx-dollar-circle bx-md text-warning'></i>
                            </div>
                            <div class="ps-3">
                                <h3><?php if(isset($cashin)): ?>
                                    <?php $__currentLoopData = $cashin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($payment->{'SUM(cash_balance)'}); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="card">
                <div class="card-body">
                    <div class="card-body">
                        <h5 class="card-title"><b>Cash Out Amount</b></h5>
                        <div class="d-flex align-items-center">
                            <div class="card-icon bg-primary p-1 rounded-circle d-flex align-items-center">
                                <i class='bx bx-dollar-circle bx-md text-warning'></i>
                            </div>
                            <div class="ps-3">
                                <h3><?php if(isset($cashout)): ?>
                                    <?php $__currentLoopData = $cashout; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($payment->{'SUM(cash_balance)'}); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="card-body">
                        <h5 class="card-title"><b>Gross Amount</b></h5>
                        <div class="d-flex align-items-center">
                            <div class="card-icon bg-primary p-1 rounded-circle d-flex align-items-center">
                                <i class='bx bx-dollar-circle bx-md text-warning'></i>
                            </div>
                            <div class="ps-3">
                                <h3><?php if(isset($grosscashamount)): ?>
                                    <?php $__currentLoopData = $grosscashamount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($payment->{'gross_cash_amount'}); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-------------------- The End Cash Inlow and Outflow Card ------------------------->
        <br>

        <!-------------------- The Game Data Card ------------------------->
        <div class="row">
            <div class="card-deck">
                <?php $__currentLoopData = $gamedata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-4 mb-3">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-body">
                                <h5 class="card-title"><b><?php echo e($data->product_name); ?></b></h5>
                                <div class="d-flex align-items-center">
                                    <div class="card-icon bg-primary p-1 rounded-circle d-flex align-items-center">
                                        <i class='bx bx-dollar-circle bx-md text-warning'></i>
                                    </div>
                                    <div class="ps-3">
                                        <h3><?php echo e($data->gross_credit_amount); ?>

                                        </h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        </div>
        <!-------------------- The End Game Data Card ------------------------->





    </div>
</div>

</div>

</body>

</html><?php /**PATH E:\Documents\Projects\firewinz\resources\views/workers/dashboard.blade.php ENDPATH**/ ?>