<form  method="post" action="<?php echo e(url('/admin/transactions/create')); ?>" class="mt-4">
              <?php echo csrf_field(); ?>

                <input type="hidden" value="<?php echo e(Session::get('User_ID')); ?>" name="User_ID" type="text">
                <input type="hidden" value="<?php echo date('Y-m-d'); ?>" name="date" type="text">



                <div class="row">
                    <div wire:ignore class="col-sm-4">
                        <label>Customer Name <sup class="text-danger fw-bold">*</sup></label>
                        <select class="select2 form-control" name="customer_name">
                            <option value="">Select an Option</option>
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value=" <?php echo e($customer->customer_id); ?>"><?php echo e($customer->customer_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <span class="text-danger">
                            <?php $__errorArgs = ['customer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>


                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                    </div>


                    <div wire:ignore class="col-sm-4">
                        <label>Game Name <sup class="text-danger fw-bold">*</sup></label>
                        <select class="select2 form-control" name="game_name">
                            <option value="">Select an Option</option>
                            <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value=" <?php echo e($game->product_id); ?>"><?php echo e($game->product_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <span class="text-danger">
                            <?php $__errorArgs = ['game_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>

                    </div>


                    <div wire:ignore class="col-sm-4">
                        <label>Type<sup class="text-danger fw-bold">*</sup></label>
                        <select class="select2 form-control" name="type">
                            <option value="">Select an Option</option>
                            <option value=" Redeem">Redeem</option>
                            <option value="Recharge">Recharge</option>
                            <option value="Freeplay">Freeplay</option>
                            <option value="Referral">Referral</option>
                        </select>
                        <span class="text-danger">
                            <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                    </div>
                </div>

                <br>
                <div class="row">
                    <div wire:ignore class="col-sm-4">
                        <label>Payment Method<sup class="text-danger fw-bold">*</sup></label>
                        <select class="select2 form-control" name="payment_method">
                            <option value="">Select an Option</option>
                            <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($payment->payment_id); ?>"><?php echo e($payment->payment_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <span class="text-danger">
                            <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                    </div>


                    <div class="col-sm-4">
                        <label>Transaction ID/Cash Identifier</label>
                        <input class="w3-input w3-border w3-round" wire:model="cash_identifier" name="cash_identifier" type="text"
                            placeholder="Cash Identifier">
                        <span class="text-danger">
                            <?php $__errorArgs = ['cash_identifier'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                    </div>

                    <div wire:ignore class="col-sm-4">
                        <label>Sender/Receiver ID</label>
                        <input class="w3-input w3-border w3-round" name="sender_receiver_id" type="text"
                            placeholder="Sender $CashTag">
                        <span class="text-danger">
                            <?php $__errorArgs = ['sender_receiver_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                    </div>
                </div>

                <br>
                <div class="row">
                    <div wire:ignore class="col-sm-4">
                        <label>Note<sup class="text-danger fw-bold">*</sup></label>
                        <input class="w3-input w3-border w3-round" name="note" type="text" placeholder="Short Note">
                        <span class="text-danger">
                            <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                    </div>

                    <div wire:ignore class="col-sm-4">
                        <label><i class="bi bi-cash"></i> Cash<sup class="text-danger fw-bold">*</sup></label>
                        <input class="w3-input w3-border w3-round" name="cash" type="text" placeholder="Short Note">
                        <span class="text-danger">
                            <?php $__errorArgs = ['cash'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                    </div>

                    <div wire:ignore class="col-sm-4">
                        <label><i class="bi bi-currency-dollar"></i> Credit<sup
                                class="text-danger fw-bold">*</sup></label>
                        <input class="w3-input w3-border w3-round" name="credit" type="text" placeholder="Short Note">
                        <span class="text-danger">
                            <?php $__errorArgs = ['credit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                    </div>


                </div>



                <?php $__currentLoopData = $access_controls2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <input type="hidden" value="<?php echo e($data->room_id); ?>" name="room_id" type="text">
                <?php break; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                <br> <br>

                <button type="submit" class="btn btn-primary mb-2">Create</button><br>
            </form><?php /**PATH E:\Documents\Projects\firewinz\resources\views/livewire/firewinz-transaction.blade.php ENDPATH**/ ?>